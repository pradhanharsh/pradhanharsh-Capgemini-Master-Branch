function abc()
{
var temp=confirm("Do You Want To Return Back?");
if(temp==true)
{

alert("Exit");
}
else
{

}
}