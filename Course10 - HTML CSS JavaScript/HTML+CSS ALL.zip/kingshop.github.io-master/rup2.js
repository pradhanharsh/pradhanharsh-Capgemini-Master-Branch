function abc()
{
var temp=confirm("Do You Want To Submit Your Feedback?");
if(temp==true)
{

alert("Thank You! You Have Successfully Submitted Feedback");
}
else
{
alert("Return Back");
}
}