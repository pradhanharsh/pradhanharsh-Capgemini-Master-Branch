function pqr()
{
var temp=confirm("Do You Want To Log In To The Online Music Store?");
if(temp==true)
{

alert("Congratulation! You Have Successfully Logged In");
}
else
{
alert("Return Back");
}
}