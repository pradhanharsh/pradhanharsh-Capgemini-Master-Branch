function abc()
{
var temp=confirm("are u want to delete");
if(temp==true)
{

alert("deleted");
}
else
{
alert("exit");
}
}