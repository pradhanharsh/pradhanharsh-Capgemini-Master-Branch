function abc()
{
var temp=confirm("Are You Want To Log In?");
if(temp==true)
{

alert("Congratulation! You Have Successfully Logged In");
}
else
{
alert("Return Back");
}
}