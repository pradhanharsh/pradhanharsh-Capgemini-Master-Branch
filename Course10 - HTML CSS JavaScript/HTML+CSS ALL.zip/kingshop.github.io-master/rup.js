function abc()
{
var temp=confirm("Do You Want To Sign Up In The E-Commerce Website?");
if(temp==true)
{

alert("Congratulation! You Have Successfully Signed Up");
}
else
{
alert("Return Back");
}
}