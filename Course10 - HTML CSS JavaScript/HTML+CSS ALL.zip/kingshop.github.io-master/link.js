function abc()
{
var temp=confirm("Do You Want To Buy This Product?");
if(temp==true)
{

alert("Congratulation! You Have Bought This Exciting Phone Successfully.");
}
else
{
alert("Return Back");
}
}