export class Add {
    constructor(
      public resName: string
    ){}
  }