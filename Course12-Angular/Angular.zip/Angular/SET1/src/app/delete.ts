export class Delete {
    constructor(
      public resName: string
    ){}
  }